# compnube-spark

This lab suggest describing a problem to solve through streaming.
